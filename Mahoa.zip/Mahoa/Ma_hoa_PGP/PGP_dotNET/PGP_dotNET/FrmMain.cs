﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Windows.Forms;

namespace PGP_dotNET
{
    public partial class PGP_Demo : Form
    {
        string originalFile, encryptedFile, outFile;
        X509Certificate2 cert;
        RSACryptoServiceProvider rsaPublic, rsaPrivate;
        //Các ký tự xuống dòng \r \n
        private static char eol1 = (char)13;
        private static char eol2 = (char)10;
        public PGP_Demo()
        {
            InitializeComponent();
        }

        private void PGP_Demo_Load(object sender, EventArgs e)
        {
            
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if(txtCerFileName.Text!="")
            {
                cert = new X509Certificate2(txtCerFileName.Text + ".cer");
                rsaPublic = (RSACryptoServiceProvider)cert.PublicKey.Key;
                originalFile = txtFile.Text.Trim();
                encryptedFile = originalFile + ".pgp";
                outFile = originalFile.Substring(0, originalFile.LastIndexOf(".")) + "_out" + originalFile.Substring(originalFile.LastIndexOf("."));
                txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": ----Begin encrypt----" + "\r\n";
                PGPencrypt(originalFile, encryptedFile, rsaPublic);
            }
            
        }
        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            //Load private key
            X509Certificate2Collection collection = new X509Certificate2Collection();
            collection.Import(txtPrivatekey.Text.Trim()+".pfx", txtPassword.Text.Trim(), X509KeyStorageFlags.PersistKeySet);
            X509Certificate2 privateCert = collection[0];
            rsaPrivate = (RSACryptoServiceProvider)privateCert.PrivateKey;
            originalFile = txtFile.Text.Trim();
            encryptedFile = originalFile + ".pgp";
            outFile = originalFile.Substring(0, originalFile.LastIndexOf(".")) + "_out" + originalFile.Substring(originalFile.LastIndexOf("."));
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": ----Begin decrypt----" + "\r\n";
            PGPdecrypt(encryptedFile, outFile, rsaPrivate);
        }

        private void PGPencrypt(string originalFile, string encryptedFile, RSACryptoServiceProvider rsaPublic)
        {
            byte[] encData;
            byte[] data = File.ReadAllBytes(originalFile);
            byte[] data1 = Encoding.ASCII.GetBytes("12");

            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Read file successfully" + "\r\n";
            //Sinh khóa phiên ngẫu nhiên sử dụng thuật toán AES-128-EBC
            Aes aes128 = Aes.Create();
            aes128.KeySize = 128;
            aes128.Mode = CipherMode.ECB;
            aes128.GenerateKey();
            
            //String s = Convert.ToBase64String(aes128.Key);
            //string s = "OljV1RZv+/JFevoy+ZJT5A==";
            //byte[] encSessionKey1 = Convert.FromBase64String(s);
            //aes128.Key = encSessionKey1;
            //byte[] encSessionKey1 = Convert.FromBase64String(System.Text.Encoding.UTF8.GetString(aes128.Key));

            //String s2 = Convert.ToBase64String(encSessionKey1);
            //Mã hóa dữ liệu sử dụng khóa phiên đối xứng AES
            MemoryStream ms = new MemoryStream();
            CryptoStream crytoStream = new CryptoStream(ms, aes128.CreateEncryptor(), CryptoStreamMode.Write);
            crytoStream.Write(data, 0, data.Length);
            crytoStream.Close();
            encData = ms.ToArray();
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Encrypt data successfully" + "\r\n";
            //Mã hóa khóa phiên sử dụng thuật toán mã hóa bất đối xứng RSA với public key
            byte[] sessionKeyByte = aes128.Key;
            byte[] encSessionKey = rsaPublic.Encrypt(sessionKeyByte, false);
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Encrypt session key successfully" + "\r\n";
            //Encode base64 khóa phiên và dữ liệu sau khi được mã hóa
            string base64EncData = Convert.ToBase64String(encData);
            string base64EncSessionKey = Convert.ToBase64String(encSessionKey).Replace("(?:\\r\\n|\\n\\r|\\n|\\r)", "");
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Encode base64 successfully" + "\r\n";
            //Ghi ra file, khóa phiên và dữ liệu sau khi được mã hóa nằm trên 2 dòng
            StreamWriter fileStr = new StreamWriter(encryptedFile);
            fileStr.WriteLine(base64EncSessionKey);
            fileStr.Write(base64EncData);
            fileStr.Flush();
            fileStr.Close();
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Write encrypted file successfully" + "\r\n";
        }

       

        private void PGPdecrypt(string encryptedFile, string decryptedFile, RSACryptoServiceProvider rsaPrivate)
        {
            byte[] allContent = File.ReadAllBytes(encryptedFile);
            //Loại bỏ các ký tự xuống dòng vô nghĩa ở đầu file
            int i = 0, s = 0;
            while (((char)allContent[i] == eol1) || ((char)allContent[i] == eol2))
                i++;
            s = i;
            //Tìm đến ký tự xuống dòng để cắt chuỗi
            while ((eol1 != (char)allContent[i]) && (eol2 != (char)allContent[i]))
                i++;
            //Cắt lấy phần khóa phiên được mã hóa và encode
            byte[] base64EncSessionKey = new byte[i-s];
            Array.Copy(allContent,s,base64EncSessionKey,0,i-s);
            //Loại bỏ các ký tự xuống dòng vô nghĩa ở giữa file
            while (((char)allContent[i] == eol1)||((char)allContent[i] == eol2))
        	    i++;
            //Loại bỏ các ký tự xuống dòng vô nghĩa ở cuối file
            int len = allContent.Length;        
            while (((char)allContent[len-1] == eol1)||((char)allContent[len-1] == eol2))
        	    len--;
            //Cắt lấy phần dữ liệu đã mã hóa và encode
            byte[] base64EncData = new byte[len-i];
            Array.Copy(allContent,i,base64EncData,0,len-i);
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Read file successfully" + "\r\n";
            //Decode base64 khóa và dữ liệu
            byte[] encSessionKey = Convert.FromBase64String(System.Text.Encoding.UTF8.GetString(base64EncSessionKey));
            byte[] encData = Convert.FromBase64String(System.Text.Encoding.UTF8.GetString(base64EncData));
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Decode base64 successfully" + "\r\n";
            //Giải mã khóa phiên sử dụng private key
            byte[] sessionKeyByte = rsaPrivate.Decrypt(encSessionKey,false);
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Decrypt session key successfully" + "\r\n";
            Aes aes128 = Aes.Create();
            aes128.Key = sessionKeyByte;
            aes128.Mode = CipherMode.ECB;
            //Giải mã dữ liệu sử dụng khóa phiên lấy được trong bước trước
            MemoryStream ms = new MemoryStream();
            CryptoStream crytoStream = new CryptoStream(ms, aes128.CreateDecryptor(), CryptoStreamMode.Write);
            crytoStream.Write(encData, 0, encData.Length);
            crytoStream.Close();
            byte[] data = ms.ToArray();
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Decrypt date successfully" + "\r\n";
            //Ghi file
            File.WriteAllBytes(decryptedFile, data);
            txtLog.Text += DateTime.Now.ToString("HH:mm:ss") + ": Write data file successfully" + "\r\n";
        }
    }
}
