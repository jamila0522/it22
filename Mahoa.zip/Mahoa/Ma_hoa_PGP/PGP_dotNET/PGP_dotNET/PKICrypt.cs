﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;

namespace PGP_dotNET
{
    class PKICrypt
    {
        public static X509Certificate2 getCertFromCerFile(string FilePath)
        {
            // Load the certificate into an X509Certificate object.
            X509Certificate2 cert = new X509Certificate2(FilePath);
            // Get the value.
            string pubString = cert.GetPublicKeyString();
            RSACryptoServiceProvider rsaprovider = (RSACryptoServiceProvider)cert.PublicKey.Key;
            return cert;
        }

        public static byte[] encrypt(byte[] data, RSACryptoServiceProvider RSAprovider)
        {
            return RSAprovider.Encrypt(data, false);
        }

        public static byte[] decrypt(byte[] data, RSACryptoServiceProvider RSAprovider)
        {
            return RSAprovider.Decrypt(data, false);
        }
        
    }
}
