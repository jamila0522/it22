﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataObjects;
using Helpers.Functions;

namespace IMTSecure
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExc_Click(object sender, EventArgs e)
        {
            try
            {
                string ip = txtIPNum.Text.Trim();
                string db = txtDB.Text.Trim();
                string user = txtUserName.Text.Trim();
                string pass = txtPassword.Text.Trim();
                string blankConnectionString = "Data Source=" + ip + ";Initial Catalog=" + db + ";User ID=" + user + ";Password=" + pass;
                string encriptConnectionString = StaticFunc.Encrypt(blankConnectionString);
                txtResult.Text = encriptConnectionString;
            }
            catch(Exception ex)
            {
                txtResult.Text = "Lỗi mã hóa : " + ex.ToString();
            }
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            TxtIP.Text = "";
            txtDB.Text = "";
            TxtUser.Text = "";
            txtPassword.Text = "";
            txtResult.Text = "";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtIP_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            try
            {
                txtDecode.Text = StaticFunc.Decrypt(txtResult.Text);
            }
            catch (Exception ex)
            {
                txtResult.Text = "Lỗi mã hóa : " + ex.ToString();
            }
        }

        private void txtDecode_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string key = Base64Encode(DateTime.Now.ToString("MM-dd-HH"));
                txtResult.Text =   key;
            }
            catch (Exception ex)
            {
                txtResult.Text = "Lỗi mã hóa : " + ex.ToString();
            }
        }
    }
}
