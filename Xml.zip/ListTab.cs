﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessObjects.Xml
{
    public class ListTab
    {
        public string index { get; set; }
        public string display { get; set; }
        public string status { get; set; }
        public int active { get; set; }
    }
}
