﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessObjects
{
    public class ColumnItem
    {
        public string columnName { get; set; }
        public string dataType { get; set; }
        public int max_length { get; set; }
        public int column_id { get; set; }

    }
}
